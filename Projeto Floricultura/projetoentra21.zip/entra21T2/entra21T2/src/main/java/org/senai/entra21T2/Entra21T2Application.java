package org.senai.entra21T2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Entra21T2Application {

	public static void main(String[] args) {
		SpringApplication.run(Entra21T2Application.class, args);
	}

}
