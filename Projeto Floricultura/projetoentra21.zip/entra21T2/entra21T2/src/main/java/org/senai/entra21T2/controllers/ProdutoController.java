package org.senai.entra21T2.controllers;

import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api")
public class ProdutoController {
	@Autowired
	ProdutoService produtoService;
	
	@GetMapping("/produtos")
	public List<Produto >listarProdutos(){
		return produtoService.listarProdutos();
}
	@PostMapping 
	public ResponseEntity<Produto> salvarProduto(@RequestBody Produto produto){
		return ResponseEntity.status(HttpStatus.CREATED).body(produtoService.salvarProduto(produto));
	}
	@PutMapping("/produto/{id}") 
	public ResponseEntity<Produto> atualizaProduto(@PathVariable Long id, @RequestBody Produto produto){
		return ResponseEntity.status(HttpStatus.OK).body(produtoService.atualizarProduto(id, produto));
		
	}
	@DeleteMapping ("/produtos/{id}")
	//método para excluir
	public ResponseEntity<Object> excluirProduto(@PathVariable Long id){
		protudoService.excluirProduto(id);
		return ReponseEntity.status(HttpStatus.OK).body("Produto excluído com sucesso!");
	}
}
