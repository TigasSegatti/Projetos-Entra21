package org.senai.entra21T2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Entra21T2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
